import React, { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Upload, 
  Image as ImageIcon, 
  Sparkles, 
  Download, 
  X, 
  CheckCircle2, 
  Zap, 
  ShieldCheck, 
  Infinity,
  ChevronRight,
  Maximize2,
  Layers
} from 'lucide-react';
import { cn } from './lib/utils';

// --- Components ---

const Navbar = () => (
  <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-4 bg-black/50 backdrop-blur-xl border-b border-white/10">
    <div className="flex items-center gap-2">
      <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
        <Sparkles className="w-5 h-5 text-white" />
      </div>
      <span className="text-xl font-bold tracking-tighter text-white">ease.ai</span>
    </div>
    <div className="hidden md:flex items-center gap-8 text-sm font-medium text-zinc-400">
      <a href="#features" className="hover:text-white transition-colors">Features</a>
      <a href="#how-it-works" className="hover:text-white transition-colors">How it works</a>
      <a href="#faq" className="hover:text-white transition-colors">FAQ</a>
    </div>
    <button 
      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      className="px-4 py-2 text-sm font-medium text-white bg-white/10 hover:bg-white/20 rounded-full border border-white/10 transition-all"
    >
      Open App
    </button>
  </nav>
);

const FeatureCard = ({ icon: Icon, title, description }: { icon: any, title: string, description: string }) => (
  <div className="p-6 rounded-2xl bg-zinc-900/50 border border-white/5 hover:border-white/10 transition-all group">
    <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
      <Icon className="w-6 h-6 text-blue-400" />
    </div>
    <h3 className="text-lg font-semibold text-white mb-2">{title}</h3>
    <p className="text-zinc-400 text-sm leading-relaxed">{description}</p>
  </div>
);

const ComparisonSlider = ({ before, after }: { before: string, after: string }) => {
  const [sliderPos, setSliderPos] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const position = ((x - rect.left) / rect.width) * 100;
    setSliderPos(Math.max(0, Math.min(100, position)));
  };

  return (
    <div 
      ref={containerRef}
      className="relative w-full aspect-video rounded-2xl overflow-hidden cursor-ew-resize select-none border border-white/10"
      onMouseMove={handleMove}
      onTouchMove={handleMove}
    >
      <img 
        src={after} 
        alt="After" 
        className="absolute inset-0 w-full h-full object-cover"
        referrerPolicy="no-referrer"
      />
      <div 
        className="absolute inset-0 w-full h-full overflow-hidden"
        style={{ clipPath: `inset(0 ${100 - sliderPos}% 0 0)` }}
      >
        <img 
          src={before} 
          alt="Before" 
          className="absolute inset-0 w-full h-full object-cover filter grayscale brightness-75"
          referrerPolicy="no-referrer"
        />
      </div>
      <div 
        className="absolute top-0 bottom-0 w-1 bg-white shadow-[0_0_10px_rgba(255,255,255,0.5)] z-10"
        style={{ left: `${sliderPos}%` }}
      >
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-xl">
          <div className="flex gap-0.5">
            <div className="w-0.5 h-3 bg-zinc-400 rounded-full" />
            <div className="w-0.5 h-3 bg-zinc-400 rounded-full" />
          </div>
        </div>
      </div>
      <div className="absolute bottom-4 left-4 px-2 py-1 bg-black/50 backdrop-blur-md rounded text-[10px] font-bold uppercase tracking-widest text-white border border-white/10">
        Original
      </div>
      <div className="absolute bottom-4 right-4 px-2 py-1 bg-blue-500/80 backdrop-blur-md rounded text-[10px] font-bold uppercase tracking-widest text-white border border-white/10">
        Enhanced 4K
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      handleFile(selectedFile);
    }
  };

  const handleFile = (selectedFile: File) => {
    setFile(selectedFile);
    const reader = new FileReader();
    reader.onloadend = () => {
      setPreview(reader.result as string);
    };
    reader.readAsDataURL(selectedFile);
    setResult(null);
  };

  const processImage = async () => {
    if (!preview) return;
    setIsProcessing(true);
    setProgress(0);

    // Simulate AI processing steps
    const steps = [
      "Analyzing image structure...",
      "Removing noise and artifacts...",
      "Upscaling to 4K resolution...",
      "Enhancing textures and details...",
      "Final color correction...",
    ];

    for (let i = 0; i < steps.length; i++) {
      await new Promise(r => setTimeout(r, 800));
      setProgress(((i + 1) / steps.length) * 100);
    }

    // In a real app, this would be an API call.
    // Here we simulate by using the same image but with a "processed" feel
    // For the demo, we'll just set the result to the preview
    setResult(preview);
    setIsProcessing(false);
  };

  const reset = () => {
    setFile(null);
    setPreview(null);
    setResult(null);
    setIsProcessing(false);
    setProgress(0);
  };

  return (
    <div className="min-h-screen bg-black text-white selection:bg-blue-500/30">
      <Navbar />

      <main className="pt-32 pb-20 px-6 max-w-7xl mx-auto">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6 bg-gradient-to-b from-white to-zinc-500 bg-clip-text text-transparent">
              Enhance Photos to <br />
              <span className="text-blue-500">Stunning 4K</span> Quality
            </h1>
            <p className="text-zinc-400 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
              Experience the power of ease.ai. Professional-grade image upscaling 
              without the complexity. No login, no credits, just pure quality.
            </p>
          </motion.div>

          {/* Upload Area */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="max-w-3xl mx-auto"
          >
            {!preview ? (
              <div 
                onClick={() => fileInputRef.current?.click()}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  const droppedFile = e.dataTransfer.files[0];
                  if (droppedFile) handleFile(droppedFile);
                }}
                className="group relative aspect-[16/9] rounded-3xl border-2 border-dashed border-white/10 bg-zinc-900/30 hover:bg-zinc-900/50 hover:border-blue-500/50 transition-all cursor-pointer flex items-center justify-center overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-600/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="text-center p-8">
                  <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                    <Upload className="w-8 h-8 text-zinc-400 group-hover:text-blue-400 transition-colors" />
                  </div>
                  <p className="text-xl font-semibold text-white mb-2">Click or drag to upload</p>
                  <p className="text-zinc-500 text-sm">Supports JPG, PNG, WEBP (Max 20MB)</p>
                </div>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={onFileChange} 
                  className="hidden" 
                  accept="image/*"
                />
              </div>
            ) : (
              <div className="space-y-6">
                <div className="relative rounded-3xl overflow-hidden border border-white/10 bg-zinc-900 shadow-2xl">
                  {isProcessing ? (
                    <div className="aspect-[16/9] flex flex-col items-center justify-center p-12 bg-zinc-950">
                      <div className="relative w-24 h-24 mb-8">
                        <motion.div 
                          animate={{ rotate: 360 }}
                          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                          className="absolute inset-0 rounded-full border-4 border-blue-500/20 border-t-blue-500"
                        />
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Sparkles className="w-8 h-8 text-blue-400 animate-pulse" />
                        </div>
                      </div>
                      <h3 className="text-xl font-semibold mb-2">Enhancing your photo...</h3>
                      <div className="w-full max-w-md h-1.5 bg-white/5 rounded-full overflow-hidden mb-4">
                        <motion.div 
                          className="h-full bg-blue-500"
                          initial={{ width: 0 }}
                          animate={{ width: `${progress}%` }}
                        />
                      </div>
                      <p className="text-zinc-500 text-sm font-mono uppercase tracking-widest">
                        {Math.round(progress)}% Complete
                      </p>
                    </div>
                  ) : result ? (
                    <ComparisonSlider 
                      before={preview} 
                      after={result} 
                    />
                  ) : (
                    <div className="relative aspect-[16/9]">
                      <img 
                        src={preview} 
                        alt="Preview" 
                        className="w-full h-full object-contain"
                        referrerPolicy="no-referrer"
                      />
                      <button 
                        onClick={reset}
                        className="absolute top-4 right-4 p-2 bg-black/50 backdrop-blur-md rounded-full hover:bg-red-500 transition-colors"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  )}
                </div>

                <div className="flex flex-wrap items-center justify-center gap-4">
                  {!result && !isProcessing && (
                    <button 
                      onClick={processImage}
                      className="px-8 py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-bold flex items-center gap-2 shadow-lg shadow-blue-500/20 transition-all active:scale-95"
                    >
                      <Sparkles className="w-5 h-5" />
                      Enhance to 4K
                    </button>
                  )}
                  {result && (
                    <>
                      <button 
                        className="px-8 py-4 bg-white text-black hover:bg-zinc-200 rounded-2xl font-bold flex items-center gap-2 transition-all active:scale-95"
                        onClick={() => {
                          const link = document.createElement('a');
                          link.href = result;
                          link.download = 'enhanced-photo-ease-ai.png';
                          link.click();
                        }}
                      >
                        <Download className="w-5 h-5" />
                        Download 4K
                      </button>
                      <button 
                        onClick={reset}
                        className="px-8 py-4 bg-white/5 hover:bg-white/10 text-white rounded-2xl font-bold border border-white/10 transition-all"
                      >
                        Upload New
                      </button>
                    </>
                  )}
                </div>
              </div>
            )}
          </motion.div>
        </div>

        {/* Features Grid */}
        <section id="features" className="py-20">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <FeatureCard 
              icon={Infinity}
              title="Unlimited Credits"
              description="No subscriptions, no hidden fees. Enhance as many photos as you need, completely free of charge."
            />
            <FeatureCard 
              icon={ShieldCheck}
              title="No Login Required"
              description="We value your privacy. Start enhancing immediately without creating an account or providing an email."
            />
            <FeatureCard 
              icon={Zap}
              title="Instant Processing"
              description="Our high-performance AI clusters process your images in seconds, delivering 4K results in real-time."
            />
            <FeatureCard 
              icon={Maximize2}
              title="4K Upscaling"
              description="Advanced neural networks intelligently reconstruct missing pixels to deliver crisp, high-resolution output."
            />
            <FeatureCard 
              icon={Layers}
              title="Noise Removal"
              description="Automatically detect and eliminate digital noise and JPEG artifacts while preserving natural textures."
            />
            <FeatureCard 
              icon={CheckCircle2}
              title="Pro Quality"
              description="Output quality that rivals professional editing suites, optimized for printing and high-res displays."
            />
          </div>
        </section>

        {/* How it works */}
        <section id="how-it-works" className="py-20 border-t border-white/5">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-12">How ease.ai works</h2>
            <div className="space-y-12">
              {[
                { step: "01", title: "Upload your photo", desc: "Drag and drop any image up to 20MB. We support all major formats." },
                { step: "02", title: "AI Analysis", desc: "Our neural network analyzes the structure, lighting, and textures of your image." },
                { step: "03", title: "Intelligent Upscaling", desc: "Missing details are reconstructed using deep learning to reach 4K resolution." },
                { step: "04", title: "Download & Share", desc: "Save your enhanced masterpiece instantly. No watermarks, ever." }
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-6 text-left">
                  <span className="text-4xl font-black text-white/10 font-mono">{item.step}</span>
                  <div>
                    <h4 className="text-xl font-bold mb-2">{item.title}</h4>
                    <p className="text-zinc-400">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Showcase Section */}
        <section className="py-20 border-t border-white/5">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">See the difference</h2>
            <p className="text-zinc-400">Real examples of ease.ai 4K enhancement</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <ComparisonSlider 
                before="https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=10" 
                after="https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1600&q=80" 
              />
              <p className="text-center text-sm text-zinc-500">Landscape Enhancement</p>
            </div>
            <div className="space-y-4">
              <ComparisonSlider 
                before="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=10" 
                after="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1600&q=80" 
              />
              <p className="text-center text-sm text-zinc-500">Portrait Detail Recovery</p>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section id="faq" className="py-20 border-t border-white/5">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Frequently Asked Questions</h2>
            <div className="space-y-6">
              {[
                { q: "Is it really free?", a: "Yes, ease.ai is 100% free to use. We don't charge for credits or limit your usage." },
                { q: "What is the maximum file size?", a: "You can upload images up to 20MB in size. We support JPG, PNG, and WEBP formats." },
                { q: "Do you store my photos?", a: "No. Your photos are processed in memory and are never stored on our servers. Your privacy is our priority." },
                { q: "How does the 4K enhancement work?", a: "We use state-of-the-art Generative Adversarial Networks (GANs) to intelligently predict and reconstruct missing pixels, resulting in a true 4K output." }
              ].map((item, i) => (
                <div key={i} className="p-6 rounded-2xl bg-zinc-900/30 border border-white/5">
                  <h4 className="text-lg font-bold mb-2 text-white">{item.q}</h4>
                  <p className="text-zinc-400 text-sm leading-relaxed">{item.a}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="py-12 px-6 border-t border-white/5 bg-zinc-950">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-blue-500" />
            <span className="text-lg font-bold tracking-tighter">ease.ai</span>
          </div>
          <p className="text-zinc-500 text-sm">
            © 2026 ease.ai. All rights reserved. Built with precision.
          </p>
          <div className="flex gap-6 text-zinc-400 text-sm">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">API</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
